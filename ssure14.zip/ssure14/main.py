
from bpe import BPETokenizer

import json

import sys



def main():

    try:
        command = sys.argv[1]

        bpe_tokenizer = BPETokenizer()

        if command == "--encode":
            encoded = bpe_tokenizer.encode(sys.argv[2])
            print(encoded)

        elif command == "--decode":
            token_ids = json.loads(sys.argv[2]) 
            decoded = bpe_tokenizer.decode(token_ids)
            print(decoded)

        elif command == "--tokenize":
            token_id = bpe_tokenizer.tokenize(sys.argv[2])
            print(token_id)

        else:
            print('Unknown command. Use --encode or --decode or --tokenize  like --decode "[12,23,23,23]"')
    except:
            print('Unknown command. Use --encode or --decode or --tokenize like --decode "[12,23,23,23]"')
if __name__ == "__main__":
    main()