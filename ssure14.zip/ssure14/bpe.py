from collections import defaultdict
from transformers import AutoTokenizer 
import warnings
warnings.filterwarnings("ignore", category=FutureWarning)
import json
import sys

class BPETokenizer:
    
    def __init__(self):

        self.vocab_size = 2000
        self.word_freqs = defaultdict(int)
        self.tokenizer = AutoTokenizer.from_pretrained("gpt2")
        
        try:
            with open('tokenizer/tokenizer.json', 'r') as file:
                data = json.load(file)
            self.vocab = data['tokens']
        except:
            self.vocab = []
            pass
        
        
    def compute_pair_freqs(self,splits):
        pair_freqs = defaultdict(int)
        for word, freq in self.word_freqs.items():
            split = splits[word]
            if len(split) == 1:
                continue
            for i in range(len(split) - 1):
                pair = (split[i], split[i + 1])
                pair_freqs[pair] += freq
        return pair_freqs
    
    def merge_pair(self,a, b, splits):
        for word in self.word_freqs:
            split = splits[word]
            if len(split) == 1:
                continue

            i = 0
            while i < len(split) - 1:
                if split[i] == a and split[i + 1] == b:
                    split = split[:i] + [a + b] + split[i + 2 :]
                else:
                    i += 1
            splits[word] = split
        return splits


    def build_vocab(self, corpus):
        self.vocab =["<|endoftext|>"]
        for text in corpus:
            words_with_offsets = self.tokenizer.backend_tokenizer.pre_tokenizer.pre_tokenize_str(text)
            new_words = [word for word, offset in words_with_offsets]
            for word in new_words:
                self.word_freqs[word] += 1

        alphabet = []

        for word in self.word_freqs.keys():
            for letter in word:
                if letter not in alphabet:
                    alphabet.append(letter)
        alphabet.sort()

        splits = {word: [c for c in word] for word in self.word_freqs.keys()}

        while len(self.vocab) < self.vocab_size:
            pair_freqs = self.compute_pair_freqs(splits)
            best_pair = ""
            max_freq = None
            for pair, freq in pair_freqs.items():
                if max_freq is None or max_freq < freq:
                    best_pair = pair
                    max_freq = freq
            if len(best_pair) == 2:
                splits = self.merge_pair(best_pair[0],best_pair[1], splits)
                self.vocab.append(best_pair[0] + best_pair[1])
            else:
                break
        
        
    def tokenize(self, text):
        
        text = text.replace(" ","Ġ")
        tokens = []
        i = 0
        while i < len(text):
            match_found = False
            for j in range(len(text), i, -1):
                subword = text[i:j]
                if subword in self.vocab:
                    tokens.append(subword)
                    i = j 
                    match_found = True
                    break
            
            if not match_found:
                tokens.append(text[i])
                if text[i] not in self.vocab:
                    self.vocab.append(text[i])
                i += 1

        json_data = {"tokens": self.vocab }
        with open('tokenizer/tokenizer.json', 'w', encoding='utf-8') as outfile:
            json.dump(json_data, outfile, ensure_ascii=False, indent=4) 
        return tokens
    
    def encode(self,text):
        tokens = self.tokenize(text)
        token_ids = [self.vocab.index(t) for t in tokens if t in self.vocab]
        return(token_ids)


    def decode(self,token_ids):
        tokens = [self.vocab[id] for id in token_ids]
        decoded_string = ''.join(tokens)
        decoded_string = decoded_string.replace('Ġ', ' ').strip()
        return decoded_string
    

    def build_new_vocab(self,file_path):
        with open(file_path, 'r') as file:
            data = json.load(file)

        corpus = data['output']
        self.build_vocab(corpus)
        
        json_data = {"tokens": self.vocab }

        with open('tokenizer/tokenizer.json', 'w', encoding='utf-8') as outfile:
         json.dump(json_data, outfile, ensure_ascii=False, indent=4)





def main():
    command = ""
    try:
         command = sys.argv[1]
    except:
        print('Use command --train like --train "file_path" ')

    bpeT = BPETokenizer()

    if command == "--train":
        bpeT.build_new_vocab(sys.argv[2])
    
    else:
        print("Unknown command. Use --train")

if __name__ == "__main__":
    main()